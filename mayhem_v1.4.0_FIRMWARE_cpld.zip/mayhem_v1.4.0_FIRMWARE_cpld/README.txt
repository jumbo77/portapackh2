Plug HackRF+Portapack, set it in HackRF mode, launch flash_portapack_mayhem_new_cpld.bat
because new cpld already flash fw,so if hackrf portack mayhem downlad fail,not halt,just boot the Application.
if you want update new fw,plug hackrf nothing happen,press DFU button then press RESET,click dfu_hackrf_one.bat then click flash_portapack_mayhem_xxx.bat